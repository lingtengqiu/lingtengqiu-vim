#include "auto_include.h"

void do_another_thing()
{
}

void do_a_thing( Thing t )
{
}
