#include <stdio.h>

struct Test
{
  int this_is_a_thing; int that_is_a_thing;
};

int main() {
  Test t;

}
