#import "SWObject.h"

@implementation SWObject

- (void)test {
  [self test:0 /*complete at here*/]
}

- /*complete at here*/

@end
