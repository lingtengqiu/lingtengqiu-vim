package good //@diag("package", "", "")

func stuff() { //@item(good_stuff, "stuff()", "", "func")
	x := 5
	random2(x)
}
